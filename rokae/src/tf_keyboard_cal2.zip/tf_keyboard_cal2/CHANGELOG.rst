^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package tf_keyboard_cal
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.0 (2016-02-09)
------------------
* Install launch files
* Added new screenshot for imarkers
* Updated README, tweaked arrow
* Adding TF Interactive marker
* Contributors: Dave Coleman, Gaël Ecorchard, Sammy Pfeiffer

0.0.6 (2016-01-13)
------------------
* API deprecation fix for rosparam_shortcuts
* Contributors: Dave Coleman

0.0.5 (2015-12-27)
------------------
* Fix roslaunch file
* Updated README
* Contributors: Dave Coleman

0.0.4 (2015-12-05)
------------------
* catkin lint cleanup
* Fixed travis
* Contributors: Dave Coleman

0.0.3 (2015-12-03)
------------------
* Rename dependency ros_param_shortcuts to rosparam_shortcuts
* Contributors: Dave Coleman

0.0.2 (2015-12-03)
------------------
* Initial Commit
* Contributors: Andy McEvoy, Dave Coleman
